import { useState } from 'react';
import Header from './components/Header';
import Home from './pages/Home';
import Patients from './pages/Patients';
import About from './pages/About';

function App() {
  // State to manage current page navigation
  const [currentPage, setCurrentPage] = useState('Home');

  // Function to handle page navigation
  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  // Render the appropriate page based on current state
  const renderPage = () => {
    switch (currentPage) {
      case 'Home':
        return <Home onNavigate={handleNavigate} />;
      case 'Patients':
        return <Patients />;
      case 'About':
        return <About />;
      default:
        return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      {renderPage()}
    </div>
  );
}

export default App;
