import { Heart, Target, Users, Zap } from 'lucide-react';

// About page with company information and mission
export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-6">
            <div className="bg-gradient-to-br from-teal-500 to-cyan-600 p-4 rounded-2xl shadow-lg">
              <Heart className="w-12 h-12 text-white" fill="white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-gray-800 mb-6">
            About <span className="bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">Jarurat Care</span>
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            We are committed to revolutionizing healthcare management through innovative
            technology solutions that prioritize patient care and operational efficiency.
          </p>
        </div>

        {/* Mission Section */}
        <div className="bg-white rounded-3xl shadow-xl p-12 mb-12 max-w-4xl mx-auto">
          <div className="flex items-start gap-6">
            <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-2xl flex-shrink-0">
              <Target className="w-10 h-10 text-teal-600" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Mission</h2>
              <p className="text-gray-600 text-lg leading-relaxed">
                At Jarurat Care, our mission is to empower healthcare professionals with cutting-edge
                tools that streamline patient record management, enhance care coordination, and ultimately
                improve patient outcomes. We believe that by simplifying administrative tasks, healthcare
                providers can focus more on what truly matters—delivering exceptional patient care.
              </p>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="max-w-6xl mx-auto mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Our Core Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Value 1 */}
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-full w-fit mb-4">
                <Users className="w-8 h-8 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Patient-Centric</h3>
              <p className="text-gray-600">
                Every decision we make is guided by how it will improve patient care and experience.
                Your patients are our priority.
              </p>
            </div>

            {/* Value 2 */}
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-full w-fit mb-4">
                <Zap className="w-8 h-8 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Innovation</h3>
              <p className="text-gray-600">
                We continuously innovate and adapt to the evolving needs of healthcare providers
                and their patients.
              </p>
            </div>

            {/* Value 3 */}
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-full w-fit mb-4">
                <Heart className="w-8 h-8 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Compassion</h3>
              <p className="text-gray-600">
                We understand the importance of healthcare and approach every feature with
                empathy and care.
              </p>
            </div>
          </div>
        </div>

        {/* Story Section */}
        <div className="bg-gradient-to-r from-teal-500 to-cyan-600 rounded-3xl p-12 text-white max-w-4xl mx-auto shadow-2xl">
          <h2 className="text-3xl font-bold mb-6">Our Story</h2>
          <p className="text-teal-50 text-lg leading-relaxed mb-4">
            Founded with a vision to bridge the gap between healthcare and technology, Jarurat Care
            emerged from the understanding that healthcare professionals need efficient, reliable,
            and user-friendly tools to manage patient information.
          </p>
          <p className="text-teal-50 text-lg leading-relaxed">
            Today, we continue to grow and evolve, driven by feedback from healthcare providers
            and guided by our commitment to making healthcare management simpler, faster, and
            more effective for everyone involved.
          </p>
        </div>

        {/* Contact CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-600 text-lg mb-4">
            Want to learn more or get in touch?
          </p>
          <a
            href="mailto:contact@jaruratcare.com"
            className="inline-block bg-gradient-to-r from-teal-500 to-cyan-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:from-teal-600 hover:to-cyan-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Contact Us
          </a>
        </div>
      </div>
    </div>
  );
}
