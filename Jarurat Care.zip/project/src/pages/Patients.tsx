import { useState, useEffect } from 'react';
import { Loader, UserPlus, AlertCircle } from 'lucide-react';
import PatientCard, { Patient } from '../components/PatientCard';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import AddPatientForm from '../components/AddPatientForm';
import patientsData from '../data/patients.json';

// Patients page with search, modal, and add patient functionality
export default function Patients() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch patient data on component mount
  useEffect(() => {
    const fetchPatients = async () => {
      try {
        setIsLoading(true);

        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 800));

        // Load patients from local JSON
        setPatients(patientsData as Patient[]);
        setFilteredPatients(patientsData as Patient[]);
        setError(null);
      } catch (err) {
        setError('Failed to load patient data. Please try again later.');
        console.error('Error fetching patients:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPatients();
  }, []);

  // Filter patients based on search query
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredPatients(patients);
    } else {
      const filtered = patients.filter(patient =>
        patient.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredPatients(filtered);
    }
  }, [searchQuery, patients]);

  // Handle adding new patient
  const handleAddPatient = (newPatient: Omit<Patient, 'id'>) => {
    const patientWithId = {
      ...newPatient,
      id: patients.length > 0 ? Math.max(...patients.map(p => p.id)) + 1 : 1,
    };

    const updatedPatients = [...patients, patientWithId];
    setPatients(updatedPatients);
    setFilteredPatients(updatedPatients);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Loader className="w-12 h-12 text-teal-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600 text-lg">Loading patient records...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Error Loading Data</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Patient Records</h1>
          <p className="text-gray-600">Manage and view all patient information</p>
        </div>

        {/* Search and Add Patient Section */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Search patients by name..."
          />
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-teal-500 to-cyan-600 text-white px-6 py-3 rounded-lg font-medium hover:from-teal-600 hover:to-cyan-700 transition-all duration-200 shadow-md hover:shadow-lg whitespace-nowrap"
          >
            <UserPlus className="w-5 h-5" />
            Add New Patient
          </button>
        </div>

        {/* Patient Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing <span className="font-semibold text-teal-600">{filteredPatients.length}</span> of{' '}
            <span className="font-semibold text-teal-600">{patients.length}</span> patients
          </p>
        </div>

        {/* Patient Cards Grid */}
        {filteredPatients.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl shadow-lg text-center">
            <p className="text-gray-600 text-lg">No patients found matching your search.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPatients.map((patient) => (
              <PatientCard
                key={patient.id}
                patient={patient}
                onViewDetails={setSelectedPatient}
              />
            ))}
          </div>
        )}
      </div>

      {/* Patient Details Modal */}
      {selectedPatient && (
        <Modal
          patient={selectedPatient}
          onClose={() => setSelectedPatient(null)}
        />
      )}

      {/* Add Patient Form Modal */}
      {showAddForm && (
        <AddPatientForm
          onClose={() => setShowAddForm(false)}
          onAddPatient={handleAddPatient}
        />
      )}
    </div>
  );
}
