import { Heart, Users, Clock, Shield } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

// Home page component with hero section and features
export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 mb-6">
            <div className="bg-gradient-to-br from-teal-500 to-cyan-600 p-4 rounded-2xl shadow-lg">
              <Heart className="w-12 h-12 text-white" fill="white" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6">
            Welcome to <span className="bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">Jarurat Care</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Your trusted partner in healthcare management. Streamline patient records,
            enhance care delivery, and make a difference in people's lives.
          </p>
          <button
            onClick={() => onNavigate('Patients')}
            className="bg-gradient-to-r from-teal-500 to-cyan-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:from-teal-600 hover:to-cyan-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            View Patient Records
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
          Why Choose Jarurat Care?
        </h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Feature 1 */}
          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
            <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-full w-fit mb-4">
              <Users className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Patient Management
            </h3>
            <p className="text-gray-600">
              Efficiently manage and organize patient records with our intuitive dashboard and search functionality.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
            <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-full w-fit mb-4">
              <Clock className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Quick Access
            </h3>
            <p className="text-gray-600">
              Access patient information instantly with powerful search and filtering capabilities for faster care delivery.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
            <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-4 rounded-full w-fit mb-4">
              <Shield className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Secure & Reliable
            </h3>
            <p className="text-gray-600">
              Your data is protected with industry-standard security measures ensuring patient privacy and confidentiality.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-teal-500 to-cyan-600 rounded-3xl p-12 text-center text-white shadow-2xl max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-teal-50 mb-8 text-lg">
            Join us in transforming healthcare management, one patient at a time.
          </p>
          <button
            onClick={() => onNavigate('Patients')}
            className="bg-white text-teal-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-50 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Explore Now
          </button>
        </div>
      </section>
    </div>
  );
}
