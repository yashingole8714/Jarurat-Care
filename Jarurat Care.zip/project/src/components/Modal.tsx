import { X, User, Phone, Mail, MapPin, Droplet, FileText, Calendar } from 'lucide-react';
import { Patient } from './PatientCard';

interface ModalProps {
  patient: Patient | null;
  onClose: () => void;
}

// Modal component to display detailed patient information
export default function Modal({ patient, onClose }: ModalProps) {
  if (!patient) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-teal-500 to-cyan-600 text-white p-6 rounded-t-2xl relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-all"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-4">
            <div className="bg-white/20 p-4 rounded-full">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">{patient.name}</h2>
              <p className="text-teal-50">Patient ID: #{patient.id}</p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            {/* Age */}
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <User className="w-5 h-5 text-teal-600 mt-1" />
              <div>
                <p className="text-sm text-gray-500 font-medium">Age</p>
                <p className="text-gray-800 font-semibold">{patient.age} years</p>
              </div>
            </div>

            {/* Blood Group */}
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Droplet className="w-5 h-5 text-red-500 mt-1" />
              <div>
                <p className="text-sm text-gray-500 font-medium">Blood Group</p>
                <p className="text-gray-800 font-semibold">{patient.bloodGroup}</p>
              </div>
            </div>

            {/* Contact */}
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Phone className="w-5 h-5 text-teal-600 mt-1" />
              <div>
                <p className="text-sm text-gray-500 font-medium">Contact</p>
                <p className="text-gray-800 font-semibold">{patient.contact}</p>
              </div>
            </div>

            {/* Last Visit */}
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Calendar className="w-5 h-5 text-teal-600 mt-1" />
              <div>
                <p className="text-sm text-gray-500 font-medium">Last Visit</p>
                <p className="text-gray-800 font-semibold">{patient.lastVisit}</p>
              </div>
            </div>
          </div>

          {/* Email */}
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <Mail className="w-5 h-5 text-teal-600 mt-1" />
            <div>
              <p className="text-sm text-gray-500 font-medium">Email</p>
              <p className="text-gray-800 font-semibold">{patient.email}</p>
            </div>
          </div>

          {/* Address */}
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <MapPin className="w-5 h-5 text-teal-600 mt-1" />
            <div>
              <p className="text-sm text-gray-500 font-medium">Address</p>
              <p className="text-gray-800 font-semibold">{patient.address}</p>
            </div>
          </div>

          {/* Medical History */}
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <FileText className="w-5 h-5 text-teal-600 mt-1" />
            <div>
              <p className="text-sm text-gray-500 font-medium">Medical History</p>
              <p className="text-gray-800 font-semibold">{patient.medicalHistory}</p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-6 bg-gray-50 rounded-b-2xl">
          <button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-teal-500 to-cyan-600 text-white py-3 rounded-lg font-medium hover:from-teal-600 hover:to-cyan-700 transition-all duration-200 shadow-md hover:shadow-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
