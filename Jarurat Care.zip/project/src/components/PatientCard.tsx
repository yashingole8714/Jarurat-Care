import { User, Phone, Calendar } from 'lucide-react';

export interface Patient {
  id: number;
  name: string;
  age: number;
  contact: string;
  email: string;
  address: string;
  bloodGroup: string;
  medicalHistory: string;
  lastVisit: string;
}

interface PatientCardProps {
  patient: Patient;
  onViewDetails: (patient: Patient) => void;
}

// Patient card component displaying basic patient info
export default function PatientCard({ patient, onViewDetails }: PatientCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 p-6 border border-gray-100 hover:border-teal-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-teal-100 to-cyan-100 p-3 rounded-full">
            <User className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-800">{patient.name}</h3>
            <p className="text-sm text-gray-500">Age: {patient.age} years</p>
          </div>
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center gap-2 text-gray-600">
          <Phone className="w-4 h-4 text-teal-500" />
          <span className="text-sm">{patient.contact}</span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <Calendar className="w-4 h-4 text-teal-500" />
          <span className="text-sm">Last Visit: {patient.lastVisit}</span>
        </div>
      </div>

      <button
        onClick={() => onViewDetails(patient)}
        className="w-full bg-gradient-to-r from-teal-500 to-cyan-600 text-white py-2 rounded-lg font-medium hover:from-teal-600 hover:to-cyan-700 transition-all duration-200 shadow-md hover:shadow-lg"
      >
        View Details
      </button>
    </div>
  );
}
